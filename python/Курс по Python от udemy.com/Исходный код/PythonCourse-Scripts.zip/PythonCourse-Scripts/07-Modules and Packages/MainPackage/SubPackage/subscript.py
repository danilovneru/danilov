def hello_subscript():
	print('Hello subscript')
	
def hello_indeed():
	print('Indeed Hello')