def hello_main():
	print('Hello from Main')
	